#ifndef MATH_UTILS_H
#define MATH_UTILS_H

int add(int a, int b) {

	return a + b;


}

#endif // MATH_UTILS_H
