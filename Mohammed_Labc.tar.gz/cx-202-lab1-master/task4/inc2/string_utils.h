#ifndef STRING_UTILS_H
#define STRING_UTILS_H
void print_message(const char* message);
#endif
