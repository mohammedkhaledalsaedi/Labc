#include <stdio.h>
#include "string_utils.h"
void print_message(const char* message) {
   printf("Message: %s\n", message);
}

