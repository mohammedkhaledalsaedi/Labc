#include <stdio.h>

int main() {
    int num = 10;
    //int n = 1;
    //int d = 2;
    printf("Number is: %d\n", num);  // Added %d to print the value of num
    return 0;
}


//This is After fixing the mistakes

